

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  16  1  0  62:14    9  3  5  31:15    93:29  +64   79
 2. 1. FC Köln                    34  14  3  0  43:16    2  8  7  23:35    66:51  +15   59
 3. Fortuna Düsseldorf            34  10  5  2  34:19    5  7  5  28:26    62:45  +17   57
 4. Bor. Mönchengladbach          34  12  1  4  57:29    5  4  8  25:32    82:61  +21   56
 5. Wuppertaler SV                34  11  4  2  42:22    4  6  7  20:27    62:49  +13   55
 6. VfB Stuttgart                 34  13  2  2  51:19    4  1 12  20:46    71:65   +6   54
 7. Eintracht Frankfurt           34  13  2  2  39:20    2  2 13  19:34    58:54   +4   49
 8. Kickers Offenbach             34  11  3  3  35:20    3  4 10  26:40    61:60   +1   49
 9. 1. FC Kaiserslautern          34  10  6  1  37:18    2  4 11  21:50    58:68  -10   46
10. MSV Duisburg                  34   8  4  5  30:18    4  5  8  23:36    53:54   -1   45
11. Werder Bremen                 34   9  3  5  29:21    3  4 10  21:31    50:52   -2   43
12. VfL Bochum                    34   9  5  3  36:24    2  4 11  14:44    50:68  -18   42
13. Hertha BSC                    34  11  2  4  39:23    0  6 11  14:41    53:64  -11   41
14. Hamburger SV                  34   9  4  4  31:17    1  4 12  22:42    53:59   -6   38
15. FC Schalke 04                 34   8  6  3  35:19    2  2 13  11:42    46:61  -15   38
16. Hannover 96                   34   7  7  3  30:25    2  1 14  19:40    49:65  -16   35
17. Eintracht Braunschweig        34   7  6  4  20:17    2  1 14  13:39    33:56  -23   34
18. Rot-Weiss Oberhausen          34   9  3  5  28:26    0  1 16  17:58    45:84  -39   31
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

