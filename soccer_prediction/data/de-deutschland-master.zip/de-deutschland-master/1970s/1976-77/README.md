

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  11  5  1  39:13    6  5  6  19:21    58:34  +24   61
 2. FC Schalke 04                 34  11  4  2  40:22    6  5  6  37:30    77:52  +25   60
 3. Eintracht Frankfurt           34  12  3  2  52:25    5  5  7  34:32    86:57  +29   59
 4. Eintracht Braunschweig        34  10  5  2  33:15    5  8  4  23:23    56:38  +18   58
 5. 1. FC Köln                    34  12  4  1  55:23    5  2 10  28:38    83:61  +22   57
 6. Hamburger SV                  34  12  3  2  44:21    2  7  8  23:35    67:56  +11   52
 7. Bayern München                34  10  4  3  49:25    4  5  8  25:40    74:65   +9   51
 8. Hertha BSC                    34  10  3  4  32:22    3  5  9  23:32    55:54   +1   47
 9. Borussia Dortmund             34   7  6  4  41:30    5  4  8  32:34    73:64   +9   46
10. Werder Bremen                 34   9  6  2  27:16    4  1 12  24:43    51:59   -8   46
11. MSV Duisburg                  34   8  8  1  32:17    3  4 10  28:34    60:51   +9   45
12. Fortuna Düsseldorf            34   7  3  7  31:26    4  6  7  21:28    52:54   -2   42
13. 1. FC Kaiserslautern          34  11  2  4  37:20    1  3 13  16:39    53:59   -6   41
14. VfL Bochum                    34   9  2  6  31:26    2  5 10  16:36    47:62  -15   40
15. 1. FC Saarbrücken             34   6  8  3  30:21    3  3 11  13:34    43:55  -12   38
16. Karlsruher SC                 34   9  5  3  32:24    0  5 12  21:51    53:75  -22   37
17. Rot-Weiss Essen               34   7  4  6  28:42    0  4 13  21:61    49:103 -54   29
18. TeBe Berlin                   34   6  6  5  32:31    0  4 13  15:54    47:85  -38   28
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

