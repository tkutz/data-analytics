

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  3  0  69:20   10  4  3  32:18   101:38  +63   79
 2. FC Schalke 04                 34  16  1  0  54:8     8  3  6  22:27    76:35  +41   76
 3. Bor. Mönchengladbach          34  12  4  1  57:17    6  3  8  25:23    82:40  +42   61
 4. 1. FC Köln                    34  11  3  3  38:18    4 10  3  26:26    64:44  +20   58
 5. Eintracht Frankfurt           34  14  3  0  50:17    2  4 11  21:44    71:61  +10   55
 6. Hertha BSC                    34  11  5  1  28:13    3  4 10  18:42    46:55   -9   51
 7. 1. FC Kaiserslautern          34  11  4  2  36:17    3  3 11  23:36    59:53   +6   49
 8. VfB Stuttgart                 34   9  4  4  31:24    4  5  8  21:32    52:56   -4   48
 9. VfL Bochum                    34  11  2  4  36:27    3  4 10  23:42    59:69  -10   48
10. Hamburger SV                  34  10  3  4  33:18    3  4 10  19:34    52:52        46
11. Werder Bremen                 34   9  5  3  42:20    2  4 11  21:38    63:58   +5   42
12. Fortuna Düsseldorf            34   7  5  5  21:17    3  5  9  19:36    40:53  -13   40
13. Eintracht Braunschweig        34   6  9  2  21:13    2  6  9  22:35    43:48   -5   39
14. MSV Duisburg                  34   8  5  4  25:17    2  2 13  11:34    36:51  -15   37
15. Hannover 96                   34  10  1  6  41:26    0  2 15  13:43    54:69  -15   33
16. Rot-Weiss Oberhausen          34   6  6  5  27:27    1  5 11   6:39    33:66  -33   32
17. Borussia Dortmund             34   5  6  6  18:26    1  2 14  16:57    34:83  -49   26
18. Arminia Bielefeld             34   6  4  7  25:29    0  3 14  16:46    41:75  -34   25
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

