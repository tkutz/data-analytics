

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  3  0  55:17    6  6  5  40:36    95:53  +42   69
 2. Bor. Mönchengladbach          34  11  5  1  54:19   10  1  6  39:33    93:52  +41   69
 3. Fortuna Düsseldorf            34  11  4  2  35:16    5  5  7  26:31    61:47  +14   57
 4. Eintracht Frankfurt           34  13  4  0  39:15    2  7  8  24:35    63:50  +13   56
 5. 1. FC Köln                    34  11  3  3  45:23    5  4  8  24:33    69:56  +13   55
 6. 1. FC Kaiserslautern          34  10  2  5  41:28    5  6  6  39:41    80:69  +11   53
 7. FC Schalke 04                 34  11  3  3  50:28    5  2 10  22:40    72:68   +4   53
 8. Hertha BSC                    34   9  6  2  35:23    2  5 10  21:37    56:60   -4   44
 9. Hamburger SV                  34  10  1  6  34:25    3  4 10  19:37    53:62   -9   44
10. VfB Stuttgart                 34  10  4  3  40:18    2  3 12  18:39    58:57   +1   43
11. Kickers Offenbach             34   7  4  6  36:26    4  5  8  20:36    56:62   -6   42
12. Rot-Weiss Essen               34   5  6  6  35:40    5  5  7  21:30    56:70  -14   41
13. Werder Bremen                 34   7  6  4  30:21    2  7  8  18:35    48:56   -8   40
14. MSV Duisburg                  34   7  6  4  23:16    4  1 12  19:40    42:56  -14   40
15. VfL Bochum                    34   7  6  4  28:21    2  6  9  17:36    45:57  -12   39
16. Wuppertaler SV                34   7  5  5  31:27    1  4 12  11:38    42:65  -23   33
17. Fortuna Koeln                 34   6  6  5  31:32    2  3 12  15:47    46:79  -33   33
18. Hannover 96                   34   5  5  7  25:23    1  5 11  25:43    50:66  -16   28
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

