

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  11  4  2  38:12    5  9  3  28:25    66:37  +29   61
 2. Hamburger SV                  34  13  2  2  42:13    4  5  8  17:19    59:32  +27   58
 3. Bayern München                34  13  2  2  52:17    2  8  7  20:33    72:50  +22   55
 4. 1. FC Köln                    34  10  5  2  34:18    4  6  7  28:27    62:45  +17   53
 5. Eintracht Braunschweig        34  12  5  0  37:13    2  6  9  15:35    52:48   +4   53
 6. 1. FC Kaiserslautern          34  11  3  3  41:19    4  4  9  25:41    66:60   +6   52
 7. FC Schalke 04                 34   8  6  3  48:26    5  5  7  28:29    76:55  +21   50
 8. Rot-Weiss Essen               34   9  6  2  37:24    4  5  8  24:43    61:67   -6   50
 9. Eintracht Frankfurt           34  10  5  2  44:17    3  5  9  35:41    79:58  +21   49
10. MSV Duisburg                  34   8  5  4  32:24    5  2 10  23:38    55:62   -7   46
11. Hertha BSC                    34  10  6  1  35:16    1  4 12  24:45    59:61   -2   43
12. VfL Bochum                    34  12  0  5  35:21    0  6 11  14:41    49:62  -13   42
13. Karlsruher SC                 34   9  3  5  32:27    3  3 11  14:32    46:59  -13   42
14. Werder Bremen                 34   9  5  3  33:20    2  3 12  11:35    44:55  -11   41
15. Fortuna Düsseldorf            34   8  6  3  32:18    2  4 11  15:39    47:57  -10   40
16. Hannover 96                   34   8  6  3  33:23    1  3 13  15:37    48:60  -12   36
17. Kickers Offenbach             34   8  5  4  26:28    1  4 12  14:44    40:72  -32   36
18. Bayer 05 Uerdingen            34   4  9  4  18:24    2  1 14  10:45    28:69  -41   28
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

