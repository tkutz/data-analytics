

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  54:12    8  4  5  30:21    84:33  +51   72
 2. Hamburger SV                  34  15  1  1  54:10    5  7  5  32:25    86:35  +51   68
 3. 1. FC Kaiserslautern          34  13  3  1  49:16    5  2 10  26:37    75:53  +22   59
 4. VfB Stuttgart                 34  11  3  3  44:18    6  4  7  31:35    75:53  +22   58
 5. 1. FC Köln                    34   9  5  3  47:26    5  4  8  25:29    72:55  +17   51
 6. Borussia Dortmund             34  11  4  2  43:21    3  4 10  21:35    64:56   +8   50
 7. Bor. Mönchengladbach          34   9  7  1  40:24    3  5  9  21:36    61:60   +1   48
 8. Eintracht Frankfurt           34  11  1  5  45:26    4  1 12  20:35    65:61   +4   47
 9. VfL Bochum                    34   9  5  3  24:13    4  1 12  17:31    41:44   -3   45
10. Fortuna Düsseldorf            34  10  2  5  45:31    3  4 10  17:41    62:72  -10   45
11. FC Schalke 04                 34   9  4  4  22:17    3  5  9  18:34    40:51  -11   45
12. Bayer Leverkusen              34  11  5  1  30:14    1  3 13  15:47    45:61  -16   44
13. Bayer 05 Uerdingen            34  11  1  5  31:24    1  4 12  12:37    43:61  -18   41
14. TSV 1860 München              34   9  4  4  28:16    1  6 10  14:37    42:53  -11   40
15. MSV Duisburg                  34   7  5  5  26:16    4  2 11  17:41    43:57  -14   40
16. Hertha BSC                    34   9  4  4  24:18    2  3 12  17:43    41:61  -20   40
17. Werder Bremen                 34  10  2  5  39:32    1  1 15  13:61    52:93  -41   36
18. Eintracht Braunschweig        34   6  5  6  23:21    0  3 14   9:43    32:64  -32   26
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

