

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  13  2  2  46:13    7  8  2  31:22    77:35  +42   70
 2. Bayern München                34  13  4  0  46:15    6  6  5  28:21    74:36  +38   67
 3. Hertha BSC                    34  13  3  1  46:21    3  6  8  15:22    61:43  +18   57
 4. Eintracht Braunschweig        34  12  4  1  39:15    4  3 10  13:25    52:40  +12   55
 5. FC Schalke 04                 34   9  4  4  26:13    6  2  9  18:27    44:40   +4   51
 6. Hamburger SV                  34  11  4  2  31:19    2  7  8  23:44    54:63   -9   50
 7. 1. FC Kaiserslautern          34  13  1  3  34:13    2  3 12  20:44    54:57   -3   49
 8. MSV Duisburg                  34  10  7  0  31:16    2  4 11  12:31    43:47   -4   47
 9. Hannover 96                   34   8  5  4  30:21    4  4  9  23:28    53:49   +4   45
10. Werder Bremen                 34   7  7  3  24:14    4  4  9  17:26    41:40   +1   44
11. 1. FC Köln                    34  10  3  4  33:24    1  8  8  13:32    46:56  -10   44
12. VfB Stuttgart                 34   9  6  2  33:16    2  2 13  16:33    49:49        41
13. Arminia Bielefeld             34   9  4  4  20:14    3  1 13  14:39    34:53  -19   41
14. Borussia Dortmund             34   7  6  4  35:19    3  3 11  19:41    54:60   -6   39
15. Eintracht Frankfurt           34   9  4  4  29:19    2  2 13  10:37    39:56  -17   39
16. Rot-Weiss Oberhausen          34   7  5  5  34:25    2  4 11  20:44    54:69  -15   36
17. Kickers Offenbach             34   7  4  6  32:28    2  5 10  17:37    49:65  -16   36
18. Rot-Weiss Essen               34   6  4  7  27:25    1  5 11  21:43    48:68  -20   30
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

