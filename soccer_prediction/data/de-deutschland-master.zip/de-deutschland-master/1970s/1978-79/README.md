

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hamburger SV                  34  13  3  1  50:13    8  4  5  28:19    78:32  +46   70
 2. VfB Stuttgart                 34  14  2  1  45:8     6  6  5  28:26    73:34  +39   68
 3. 1. FC Kaiserslautern          34  13  3  1  41:16    3  8  6  21:31    62:47  +15   59
 4. Bayern München                34  11  4  2  44:17    5  4  8  25:29    69:46  +23   56
 5. Eintracht Frankfurt           34  12  3  2  34:19    4  4  9  16:30    50:49   +1   55
 6. 1. FC Köln                    34   8  6  3  32:21    5  6  6  23:26    55:47   +8   51
 7. Fortuna Düsseldorf            34  10  6  1  47:23    3  5  9  23:36    70:59  +11   50
 8. Bor. Mönchengladbach          34   9  3  5  34:26    3  5  9  16:27    50:53   -3   44
 9. VfL Bochum                    34   7  6  4  26:19    3  7  7  21:27    47:46   +1   43
10. Eintracht Braunschweig        34   8  7  2  26:14    2  6  9  24:41    50:55   -5   43
11. MSV Duisburg                  34  10  3  4  27:21    2  3 12  16:35    43:56  -13   42
12. Werder Bremen                 34   8  7  2  34:23    2  4 11  14:37    48:60  -12   41
13. Borussia Dortmund             34  10  5  2  33:16    0  6 11  21:54    54:70  -16   41
14. Hertha BSC                    34   7  5  5  26:20    2  6  9  14:30    40:50  -10   38
15. FC Schalke 04                 34   7  6  4  36:26    2  4 11  19:35    55:61   -6   37
16. Arminia Bielefeld             34   6  6  5  23:19    3  2 12  20:37    43:56  -13   35
17. 1. FC Nürnberg                34   7  6  4  24:24    1  2 14  12:43    36:67  -31   32
18. SV Darmstadt 98               34   6  4  7  25:31    1  3 13  15:44    40:75  -35   28
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

