

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Köln                    34  14  1  2  58:20    8  3  6  28:21    86:41  +45   70
 2. Bor. Mönchengladbach          34  13  2  2  52:22    7  6  4  34:22    86:44  +42   68
 3. VfB Stuttgart                 34  14  2  1  42:11    3  3 11  16:29    58:40  +18   56
 4. Hertha BSC                    34  12  5  0  38:16    3  5  9  21:32    59:48  +11   55
 5. Fortuna Düsseldorf            34  12  4  1  34:13    3  5  9  15:23    49:36  +13   54
 6. Eintracht Frankfurt           34  12  1  4  42:23    4  3 10  17:29    59:52   +7   52
 7. MSV Duisburg                  34  11  4  2  40:19    4  3 10  22:40    62:59   +3   52
 8. 1. FC Kaiserslautern          34  13  1  3  38:17    3  3 11  26:46    64:63   +1   52
 9. FC Schalke 04                 34  13  1  3  33:15    1  5 11  14:37    47:52   -5   48
10. Hamburger SV                  34   9  4  4  34:24    5  2 10  27:43    61:67   -6   48
11. Borussia Dortmund             34   9  4  4  36:24    5  1 11  21:47    57:71  -14   47
12. Eintracht Braunschweig        34  12  3  2  32:15    2  1 14  11:38    43:53  -10   46
13. Werder Bremen                 34  12  2  3  38:19    1  3 13  10:38    48:57   -9   44
14. Bayern München                34  11  3  3  43:22    0  7 10  19:42    62:64   -2   43
15. VfL Bochum                    34  10  4  3  28:11    1  5 11  21:40    49:51   -2   42
16. TSV 1860 München              34   5  6  6  25:22    2  2 13  16:38    41:60  -19   29
17. 1. FC Saarbrücken             34   4  8  5  24:23    2  2 13  15:47    39:70  -31   28
18. FC St. Pauli                  34   5  5  7  28:33    1  1 15  16:53    44:86  -42   24
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

