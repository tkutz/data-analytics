

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  12  4  1  40:10    6  6  5  21:21    61:31  +30   64
 2. Alemannia Aachen              34  11  1  5  36:22    5  5  7  21:29    57:51   +6   54
 3. Bor. Mönchengladbach          34   8  6  3  34:20    5  5  7  27:26    61:46  +15   50
 4. VfB Stuttgart                 34  10  5  2  40:23    4  3 10  20:31    60:54   +6   50
 5. Eintracht Braunschweig        34   8  5  4  29:23    5  6  6  17:20    46:43   +3   50
 6. FC Schalke 04                 34  11  3  3  33:15    3  4 10  12:25    45:40   +5   49
 7. Hamburger SV                  34  10  3  4  35:22    3  7  7  20:33    55:55        49
 8. TSV 1860 München              34  11  2  4  27:21    4  2 11  17:38    44:59  -15   49
 9. Werder Bremen                 34  12  2  3  36:23    2  4 11  23:36    59:59        48
10. Eintracht Frankfurt           34   8  6  3  27:15    5  2 10  19:28    46:43   +3   47
11. 1. FC Köln                    34  11  4  2  33:18    2  2 13  14:38    47:56   -9   45
12. Hertha BSC                    34  10  3  4  20:12    2  5 10  11:27    31:39   -8   44
13. 1. FC Kaiserslautern          34  10  4  3  31:14    2  2 13  14:33    45:47   -2   42
14. Hannover 96                   34   7  7  3  28:21    2  7  8  19:24    47:45   +2   41
15. Borussia Dortmund             34   9  3  5  29:20    2  5 10  20:34    49:54   -5   41
16. MSV Duisburg                  34   7  9  1  19:10    1  7  9  14:27    33:37   -4   40
17. 1. FC Nürnberg                34   7  7  3  26:15    2  4 11  19:40    45:55  -10   38
18. Kickers Offenbach             34   9  5  3  27:19    1  3 13  15:40    42:59  -17   38
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

