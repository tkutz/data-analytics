

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. TSV 1860 München              34  11  6  0  43:17    9  4  4  37:23    80:40  +40   70
 2. Bayern München                34  12  2  3  42:15    8  5  4  29:23    71:38  +33   67
 3. Werder Bremen                 34  14  2  1  43:14    7  1  9  33:26    76:40  +36   66
 4. Borussia Dortmund             34  13  3  1  47:12    6  6  5  23:24    70:36  +34   66
 5. 1. FC Köln                    34  13  2  2  44:16    6  4  7  30:25    74:41  +33   63
 6. Eintracht Frankfurt           34  12  2  3  41:13    4  4  9  23:33    64:46  +18   54
 7. 1. FC Nürnberg                34   9  7  1  37:17    5  4  8  17:26    54:43  +11   53
 8. MSV Duisburg                  34   9  4  4  45:25    5  4  8  25:23    70:48  +22   50
 9. Hamburger SV                  34   9  3  5  41:21    4  5  8  23:31    64:52  +12   47
10. Eintracht Braunschweig        34   8  5  4  31:21    3  7  7  18:28    49:49        45
11. VfB Stuttgart                 34   9  3  5  24:12    4  3 10  18:36    42:48   -6   45
12. Hannover 96                   34   8  5  4  40:23    3  3 11  19:34    59:57   +2   41
13. Bor. Mönchengladbach          34   8  3  6  36:27    1  8  8  21:41    57:68  -11   38
14. FC Schalke 04                 34   8  6  3  22:17    2  1 14  11:38    33:55  -22   37
15. 1. FC Kaiserslautern          34   7  6  4  25:18    1  4 12  17:47    42:65  -23   34
16. Karlsruher SC                 34   9  4  4  27:22    0  2 15   8:49    35:71  -36   33
17. Borussia Neunkirchen          34   7  2  8  19:36    2  2 13  13:46    32:82  -50   31
18. Tasmania 1900 Berlin          34   2  3 12   8:46    0  1 16   7:62    15:108 -93   10
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

