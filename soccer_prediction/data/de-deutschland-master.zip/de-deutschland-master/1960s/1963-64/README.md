

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Köln                    30  10  4  1  48:21    7  7  1  30:19    78:40  +38   62
 2. Eintracht Frankfurt           30  10  3  2  43:20    6  4  5  22:21    65:41  +24   55
 3. MSV Duisburg                  30  10  4  1  36:11    3  9  3  24:25    60:36  +24   52
 4. Borussia Dortmund             30  11  3  1  54:21    3  2 10  19:36    73:57  +16   47
 5. VfB Stuttgart                 30   9  3  3  29:12    4  4  7  19:28    48:40   +8   46
 6. Hamburger SV                  30   9  6  0  45:18    2  4  9  24:42    69:60   +9   43
 7. TSV 1860 München              30   9  4  2  49:16    2  5  8  17:34    66:50  +16   42
 8. FC Schalke 04                 30  10  1  4  33:17    2  4  9  18:36    51:53   -2   41
 9. 1. FC Nürnberg                30   7  4  4  26:22    4  3  8  19:34    45:56  -11   40
10. Eintracht Braunschweig        30   8  4  3  21:13    3  2 10  15:36    36:49  -13   39
11. Werder Bremen                 30   8  5  2  32:21    2  3 10  21:41    53:62   -9   38
12. 1. FC Kaiserslautern          30   7  4  4  27:21    3  2 10  21:48    48:69  -21   36
13. Hertha BSC                    30   6  3  6  27:25    3  3  9  18:40    45:65  -20   33
14. Karlsruher SC                 30   4  5  6  24:30    4  3  8  18:25    42:55  -13   32
15. Preussen Münster              30   5  4  6  21:23    2  5  8  13:29    34:52  -18   30
16. 1. FC Saarbrücken             30   3  4  8  20:31    3  1 11  24:41    44:72  -28   23
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

