

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  12  3  2  50:17   10  4  3  23:11    73:28  +45   73
 2. Bayer Leverkusen              34  13  4  0  44:17    8  6  3  30:19    74:36  +38   73
 3. Hamburger SV                  34  11  4  2  37:11    5  7  5  26:28    63:39  +24   59
 4. TSV 1860 München              34  11  3  3  36:20    3  8  6  19:28    55:48   +7   53
 5. 1. FC Kaiserslautern          34   8  3  6  31:28    7  2  8  23:31    54:59   -5   50
 6. Hertha BSC                    34   8  7  2  23:14    5  4  8  16:32    39:46   -7   50
 7. VfL Wolfsburg                 34   9  4  4  29:26    3  9  5  22:32    51:58   -7   49
 8. VfB Stuttgart                 34   6  2  9  22:28    8  4  5  22:19    44:47   -3   48
 9. Werder Bremen                 34  10  3  4  41:25    3  5  9  24:27    65:52  +13   47
10. SpVgg Unterhaching            34  10  5  2  22:10    2  3 12  18:32    40:42   -2   44
11. Eintracht Frankfurt           34   9  3  5  29:14    3  2 12  13:30    42:44   -2   41
12. Borussia Dortmund             34   4  7  6  21:21    5  6  6  20:17    41:38   +3   40
13. SC Freiburg                   34   8  4  5  29:19    2  6  9  16:31    45:50   -5   40
14. FC Schalke 04                 34   4 10  3  21:17    4  5  8  21:27    42:44   -2   39
15. Hansa Rostock                 34   7  7  3  25:22    1  7  9  19:38    44:60  -16   38
16. SSV Ulm 1846                  34   7  4  6  22:23    2  4 11  14:39    36:62  -26   35
17. Arminia Bielefeld             34   4  6  7  22:24    3  3 11  18:37    40:61  -21   30
18. MSV Duisburg                  34   2  8  7  20:25    2  2 13  17:46    37:71  -34   22
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Köln                       68  18 10  6  70:35    9  9 16  36:54   106:89  +17  100
 2. Bochum                        34  11  1  5  41:24    7  6  4  26:24    67:48  +19   61
 3. Cottbus                       34  13  2  2  40:17    5  2 10  22:25    62:42  +20   58
 4. Nürnberg                      34  11  5  1  36:18    4  5  8  18:28    54:46   +8   55
 5. M'gladbach                    34  11  3  3  39:17    3  9  5  21:26    60:43  +17   54
 6. Oberhausen                    34   9  6  2  28:15    3  7  7  15:19    43:34   +9   49
 7. Greuther Fürth                34   4 11  2  13:8     6  5  6  27:31    40:39   +1   46
 8. Aachen                        34   8  5  4  28:18    4  5  8  18:36    46:54   -8   46
 9. Mainz                         34   8  8  1  24:10    3  4 10  17:32    41:42   -1   45
10. Hannover                      34   7  5  5  34:29    5  3  9  22:27    56:56        44
11. Chemnitz                      34   7  7  3  30:20    4  3 10  12:29    42:49   -7   43
12. Mannheim                      34   9  5  3  35:26    1  7  9  15:30    50:56   -6   42
13. TB Berlin                     34   8  4  5  25:22    2  6  9  17:28    42:50   -8   40
14. St Pauli                      34   4 10  3  15:15    4  5  8  22:30    37:45   -8   39
15. Stuttgarter K                 34   9  3  5  29:26    1  6 10  20:32    49:58   -9   39
16. Offenbach                     34   7  3  7  21:25    1  8  8  14:33    35:58  -23   35
17. Karlsruhe                     34   3  7  7  13:19    2  5 10  22:37    35:56  -21   27
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

