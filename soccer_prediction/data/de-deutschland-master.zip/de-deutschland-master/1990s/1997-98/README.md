

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Kaiserslautern          34  13  2  2  36:19    6  9  2  27:20    63:39  +24   68
 2. Bayern München                34  11  4  2  36:14    8  5  4  33:23    69:37  +32   66
 3. Bayer Leverkusen              34   9  7  1  43:17    5  6  6  23:22    66:39  +27   55
 4. VfB Stuttgart                 34  10  5  2  27:12    4  5  8  28:37    55:49   +6   52
 5. FC Schalke 04                 34  10  5  2  24:12    3  8  6  14:20    38:32   +6   52
 6. Hansa Rostock                 34   9  3  5  35:22    5  6  6  19:24    54:46   +8   51
 7. Werder Bremen                 34   8  6  3  27:23    6  2  9  16:24    43:47   -4   50
 8. MSV Duisburg                  34   6  6  5  21:20    5  5  7  22:24    43:44   -1   44
 9. Hamburger SV                  34   6  5  6  20:20    5  6  6  18:26    38:46   -8   44
10. Borussia Dortmund             34   8  4  5  36:25    3  6  8  21:30    57:55   +2   43
11. Hertha BSC                    34   7  6  4  25:22    5  1 11  16:31    41:53  -12   43
12. VfL Bochum                    34   8  4  5  23:20    3  4 10  18:29    41:49   -8   41
13. TSV 1860 München              34   7  3  7  24:24    4  5  8  19:30    43:54  -11   41
14. VfL Wolfsburg                 34   7  4  6  17:20    4  2 11  21:34    38:54  -16   39
15. Bor. Mönchengladbach          34   5  8  4  27:22    4  3 10  27:37    54:59   -5   38
16. Karlsruher SC                 34   6  5  6  26:24    3  6  8  22:36    48:60  -12   38
17. 1. FC Köln                    34   8  3  6  34:30    2  3 12  15:34    49:64  -15   36
18. Arminia Bielefeld             34   7  5  5  29:27    1  3 13  14:29    43:56  -13   32
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ein Frankfurt                 34  10  6  1  33:18    7  7  3  17:14    50:32  +18   64
 2. Freiburg                      34   9  5  3  29:16    9  2  6  28:20    57:36  +21   61
 3. Nürnberg                      34   9  4  4  25:14    8  4  5  27:21    52:35  +17   59
 4. St Pauli                      34  10  7  0  24:8     4  7  6  19:23    43:31  +12   56
 5. Gutersloh                     34   8  8  1  23:11    5  8  4  20:15    43:26  +17   55
 6. FC Köln                       34   6  6  5  27:27    5  7  5  26:26    53:53        46
 7. Dusseldorf                    34   7  4  6  27:23    6  3  8  25:31    52:54   -2   46
 8. Cottbus                       34   7  8  2  23:16    3  7  7  15:20    38:36   +2   45
 9. Greuther Fürth                34   7  8  2  21:10    4  4  9  11:22    32:32        45
10. Mainz                         34   6  8  3  31:22    4  6  7  24:26    55:48   +7   44
11. Unterhaching                  34   7  6  4  23:16    3  8  6  18:19    41:35   +6   44
12. Stuttgarter K                 34   7  3  7  26:26    5  5  7  18:21    44:47   -3   44
13. Uerdingen                     34   7  2  8  17:20    4  8  5  19:20    36:40   -4   43
14. Wattenscheid                  34   8  2  7  28:19    2  8  7  13:22    41:41        40
15. Leipzig                       34   8  6  3  19:13    2  3 12  12:38    31:51  -20   39
16. CZ Jena                       34   4  4  9  21:35    4  5  8  18:26    39:61  -22   33
17. Zwickau                       34   3  7  7  13:18    3  3 11  19:37    32:55  -23   28
18. Meppen                        34   6  5  6  24:28    0  4 13  11:33    35:61  -26   27
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

