

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  13  4  0  57:18    9  5  3  32:23    89:41  +48   75
 2. Hamburger SV                  34  14  2  1  42:17    7  5  5  31:26    73:43  +30   70
 3. VfB Stuttgart                 34  15  1  1  45:19    4  7  6  25:25    70:44  +26   65
 4. 1. FC Kaiserslautern          34  12  4  1  39:18    5  6  6  21:19    60:37  +23   61
 5. Bor. Mönchengladbach          34  10  4  3  40:28    5  3  9  28:36    68:64   +4   52
 6. Eintracht Frankfurt           34  10  6  1  37:20    3  6  8  24:37    61:57   +4   51
 7. Borussia Dortmund             34   9  6  2  47:30    4  3 10  22:29    69:59  +10   48
 8. 1. FC Köln                    34   8  4  5  33:23    4  6  7  21:32    54:55   -1   46
 9. VfL Bochum                    34   5  8  4  25:20    4  7  6  28:25    53:45   +8   42
10. Karlsruher SC                 34   7  8  2  33:20    2  6  9  23:43    56:63   -7   41
11. Bayer Leverkusen              34   9  5  3  34:17    1  5 11  18:36    52:53   -1   40
12. 1. FC Nürnberg                34   8  2  7  24:21    3  4 10  23:36    47:57  -10   39
13. MSV Duisburg                  34   8  4  5  30:24    2  5 10  15:34    45:58  -13   39
14. Fortuna Düsseldorf            34   7  6  4  34:27    3  2 12  23:37    57:64   -7   38
15. Arminia Bielefeld             34   8  3  6  28:25    2  3 12  18:40    46:65  -19   36
16. TSV 1860 München              34   7  5  5  27:24    2  2 13  22:43    49:67  -18   34
17. FC Schalke 04                 34   6  5  6  25:34    2  2 13  18:54    43:88  -45   31
18. Bayer 05 Uerdingen            34   8  3  6  28:26    0  3 14  19:53    47:79  -32   30
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

