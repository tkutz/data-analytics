

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hamburger SV                  34  12  2  3  49:20    9  4  4  26:16    75:36  +39   69
 2. Bor. Mönchengladbach          34  15  2  0  54:16    6  4  7  27:32    81:48  +33   69
 3. VfB Stuttgart                 34  12  4  1  49:12    7  6  4  30:21    79:33  +46   67
 4. Bayern München                34  14  3  0  59:14    6  4  7  25:27    84:41  +43   67
 5. Werder Bremen                 34  13  2  2  49:14    6  5  6  30:32    79:46  +33   64
 6. 1. FC Köln                    34  11  1  5  39:23    5  5  7  31:34    70:57  +13   54
 7. Bayer Leverkusen              34  10  4  3  32:16    3  4 10  18:34    50:50        47
 8. Arminia Bielefeld             34   8  5  4  25:18    4  4  9  15:31    40:49   -9   45
 9. Eintracht Braunschweig        34  10  4  3  39:20    3  2 12  15:49    54:69  -15   45
10. Bayer 05 Uerdingen            34   9  3  5  37:30    3  4 10  29:49    66:79  -13   43
11. 1. FC Kaiserslautern          34   9  5  3  41:22    3  1 13  27:47    68:69   -1   42
12. Borussia Dortmund             34  10  3  4  35:17    1  5 11  19:48    54:65  -11   41
13. Waldhof Mannheim              34   5  7  5  29:26    5  4  8  16:32    45:58  -13   41
14. Fortuna Düsseldorf            34   9  4  4  46:23    2  3 12  17:52    63:75  -12   40
15. VfL Bochum                    34   9  4  4  38:25    1  4 12  20:45    58:70  -12   38
16. Eintracht Frankfurt           34   5  8  4  24:19    2  5 10  21:42    45:61  -16   34
17. Kickers Offenbach             34   7  3  7  33:36    0  2 15  15:70    48:106 -58   26
18. 1. FC Nürnberg                34   6  2  9  29:39    0  0 17   9:46    38:85  -47   20
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

