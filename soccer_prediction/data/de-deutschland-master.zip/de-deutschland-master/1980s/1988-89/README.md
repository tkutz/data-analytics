

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  3  0  44:8     5  9  3  23:18    67:26  +41   69
 2. 1. FC Köln                    34  12  3  2  40:16    6  6  5  18:14    58:30  +28   63
 3. Werder Bremen                 34  14  2  1  35:10    4  6  7  20:22    55:32  +23   62
 4. Hamburger SV                  34   9  5  3  32:15    8  4  5  28:21    60:36  +24   60
 5. VfB Stuttgart                 34  12  3  2  39:17    4  4  9  19:32    58:49   +9   55
 6. Bor. Mönchengladbach          34   9  7  1  31:17    3  7  7  13:26    44:43   +1   50
 7. Borussia Dortmund             34   8  6  3  35:20    4  7  6  21:20    56:40  +16   49
 8. Bayer Leverkusen              34   7  7  3  26:16    3  7  7  19:28    45:44   +1   44
 9. Karlsruher SC                 34   7  6  4  26:20    5  2 10  22:31    48:51   -3   44
10. 1. FC Kaiserslautern          34   8  7  2  29:11    2  6  9  18:33    47:44   +3   43
11. FC St. Pauli                  34   9  4  4  22:13    0 10  7  19:29    41:42   -1   41
12. Waldhof Mannheim              34   6  7  4  26:28    4  4  9  17:24    43:52   -9   41
13. Bayer 05 Uerdingen            34   7  6  4  28:22    3  5  9  22:38    50:60  -10   41
14. Stuttgarter Kickers           34   6  2  9  20:26    4  4  9  21:42    41:68  -27   36
15. VfL Bochum                    34   7  5  5  21:20    2  3 12  16:37    37:57  -20   35
16. 1. FC Nürnberg                34   7  6  4  23:22    1  4 12  13:32    36:54  -18   34
17. Eintracht Frankfurt           34   6  7  4  17:17    2  3 12  13:36    30:53  -23   34
18. Hannover 96                   34   2  8  7  24:36    2  3 12  12:35    36:71  -35   23
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

