

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  13  3  1  50:18    8  5  4  29:20    79:38  +41   71
 2. Werder Bremen                 34  13  4  0  58:21    5  6  6  29:30    87:51  +36   64
 3. 1. FC Köln                    34  10  3  4  36:27    8  1  8  33:39    69:66   +3   58
 4. Bor. Mönchengladbach          34   8  6  3  45:22    7  3  7  32:31    77:53  +24   54
 5. Hamburger SV                  34  12  4  1  42:15    2  5 10  16:34    58:49   +9   51
 6. Bayer 05 Uerdingen            34  12  3  2  38:21    2  5 10  19:31    57:52   +5   50
 7. Waldhof Mannheim              34   9  5  3  30:17    4  6  7  17:33    47:50   -3   50
 8. VfB Stuttgart                 34  12  1  4  51:21    2  4 11  28:38    79:59  +20   47
 9. FC Schalke 04                 34  11  3  3  43:23    2  5 10  20:39    63:62   +1   47
10. VfL Bochum                    34   7  5  5  24:19    5  5  7  28:35    52:54   -2   46
11. 1. FC Kaiserslautern          34  10  6  1  45:18    1  5 11  11:42    56:60   -4   44
12. Borussia Dortmund             34   9  2  6  32:21    4  2 11  19:44    51:65  -14   43
13. Eintracht Frankfurt           34   9  6  2  36:22    1  6 10  26:45    62:67   -5   42
14. Bayer Leverkusen              34   8  6  3  32:22    1  7  9  20:32    52:54   -2   40
15. Fortuna Düsseldorf            34   7  6  4  30:25    3  3 11  23:41    53:66  -13   39
16. Arminia Bielefeld             34   7  5  5  34:31    1  8  8  12:30    46:61  -15   37
17. Eintracht Braunschweig        34   7  2  8  25:26    2  0 15  14:53    39:79  -40   29
18. Karlsruher SC                 34   3  9  5  24:30    2  3 12  23:58    47:88  -41   27
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

