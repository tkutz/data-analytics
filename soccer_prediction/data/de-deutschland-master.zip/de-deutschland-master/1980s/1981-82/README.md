

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hamburger SV                  34  11  6  0  59:17    7  6  4  36:28    95:45  +50   66
 2. 1. FC Köln                    34  13  2  2  43:12    5  7  5  29:26    72:38  +34   63
 3. Bayern München                34  13  3  1  52:20    7  0 10  25:36    77:56  +21   63
 4. Borussia Dortmund             34  11  1  5  38:21    7  4  6  21:19    59:40  +19   59
 5. Werder Bremen                 34  11  4  2  36:17    6  4  7  25:35    61:52   +9   59
 6. 1. FC Kaiserslautern          34  12  5  0  47:23    4  5  8  23:38    70:61   +9   58
 7. Bor. Mönchengladbach          34  10  3  4  42:25    5  7  5  19:26    61:51  +10   55
 8. Eintracht Frankfurt           34  14  1  2  56:26    3  2 12  27:46    83:72  +11   54
 9. VfB Stuttgart                 34   9  2  6  40:27    4  7  6  22:28    62:55   +7   48
10. Eintracht Braunschweig        34  12  3  2  41:19    2  1 14  20:47    61:66   -5   46
11. VfL Bochum                    34  10  5  2  33:18    2  3 12  19:33    52:51   +1   44
12. Arminia Bielefeld             34   9  4  4  28:14    3  2 12  18:36    46:50   -4   42
13. 1. FC Nürnberg                34  10  4  3  34:24    1  2 14  19:48    53:72  -19   39
14. Karlsruher SC                 34   8  5  4  30:24    1  4 12  20:44    50:68  -18   36
15. Bayer Leverkusen              34   6  5  6  20:23    3  2 12  25:49    45:72  -27   34
16. Fortuna Düsseldorf            34   6  8  3  32:22    0  5 12  16:51    48:73  -25   31
17. MSV Duisburg                  34   8  1  8  28:26    0  2 15  12:51    40:77  -37   27
18. SV Darmstadt 98               34   4  6  7  27:37    1  5 11  19:45    46:82  -36   26
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

