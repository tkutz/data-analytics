

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  41:8     5  9  3  23:20    64:28  +36   68
 2. 1. FC Köln                    34   9  4  4  32:21    8  5  4  22:23    54:44  +10   60
 3. Eintracht Frankfurt           34  11  3  3  38:16    4  8  5  23:24    61:40  +21   56
 4. Borussia Dortmund             34  11  5  1  28:8     4  6  7  23:27    51:35  +16   56
 5. Bayer Leverkusen              34   7  8  2  23:15    5  7  5  17:17    40:32   +8   51
 6. VfB Stuttgart                 34  13  3  1  38:8     2  3 12  15:39    53:47   +6   51
 7. Werder Bremen                 34   8  7  2  34:11    2  7  8  15:30    49:41   +8   44
 8. 1. FC Nürnberg                34   8  6  3  26:13    3  5  9  16:33    42:46   -4   44
 9. Hamburger SV                  34  10  3  4  26:12    3  2 12  13:34    39:46   -7   44
10. Fortuna Düsseldorf            34   6  8  3  26:15    4  4  9  15:26    41:41        42
11. Karlsruher SC                 34   8  7  2  21:11    2  5 10  11:28    32:39   -7   42
12. Bor. Mönchengladbach          34   8  5  4  27:14    3  3 11  10:31    37:45   -8   41
13. 1. FC Kaiserslautern          34   8  4  5  29:23    2  7  8  13:32    42:55  -13   41
14. Bayer 05 Uerdingen            34   7  4  6  29:24    3  6  8  12:24    41:48   -7   40
15. VfL Bochum                    34   8  5  4  27:19    3  2 12  17:34    44:53   -9   40
16. FC St. Pauli                  34   6  8  3  18:14    3  5  9  13:32    31:46  -15   40
17. Waldhof Mannheim              34   7  5  5  27:19    3  1 13   9:34    36:53  -17   36
18. FC 08 Homburg                 34   6  3  8  23:26    2  5 10  10:25    33:51  -18   32
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

