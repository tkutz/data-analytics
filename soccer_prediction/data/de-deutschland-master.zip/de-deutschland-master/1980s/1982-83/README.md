

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Werder Bremen                 34  15  2  0  52:16    8  4  5  24:22    76:38  +38   75
 2. Hamburger SV                  34  12  5  0  45:11    8  7  2  34:22    79:33  +46   72
 3. VfB Stuttgart                 34  12  4  1  48:21    8  4  5  32:26    80:47  +33   68
 4. Bayern München                34  11  3  3  43:9     6  7  4  31:24    74:33  +41   61
 5. 1. FC Köln                    34  13  3  1  45:18    4  6  7  24:24    69:42  +27   60
 6. Borussia Dortmund             34  10  4  3  53:28    6  3  8  25:34    78:62  +16   55
 7. 1. FC Kaiserslautern          34  13  2  2  43:18    1 11  5  14:26    57:44  +13   55
 8. Arminia Bielefeld             34  11  3  3  36:21    1  4 12  10:50    46:71  -25   43
 9. Eintracht Frankfurt           34  11  3  3  36:13    1  2 14  12:44    48:57   -9   41
10. Fortuna Düsseldorf            34  10  2  5  43:35    1  6 10  20:40    63:75  -12   41
11. Bor. Mönchengladbach          34   9  3  5  39:22    3  1 13  25:41    64:63   +1   40
12. Bayer Leverkusen              34   7  6  4  21:18    3  3 11  22:48    43:66  -23   39
13. 1. FC Nürnberg                34   9  5  3  31:23    2  1 14  13:47    44:70  -26   39
14. VfL Bochum                    34   6  7  4  30:19    2  5 10  13:30    43:49   -6   36
15. Eintracht Braunschweig        34   6  7  4  26:21    2  4 11  16:44    42:65  -23   35
16. FC Schalke 04                 34   6  3  8  28:28    2  3 12  20:40    48:68  -20   30
17. Karlsruher SC                 34   6  7  4  23:21    1  0 16  16:65    39:86  -47   28
18. Hertha BSC                    34   5  6  6  27:25    0  4 13  16:42    43:67  -24   25
~~~

(Source: `1-bundesliga.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

