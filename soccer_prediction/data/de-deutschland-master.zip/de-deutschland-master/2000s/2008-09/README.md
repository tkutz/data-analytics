

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. VfL Wolfsburg                 34  16  1  0  51:13    5  5  7  29:28    80:41  +39   69
 2. Bayern München                34  12  2  3  45:23    8  5  4  26:19    71:42  +29   67
 3. VfB Stuttgart                 34  12  3  2  34:14    7  4  6  29:29    63:43  +20   64
 4. Hertha BSC                    34  12  3  2  29:14    7  3  7  19:27    48:41   +7   63
 5. Hamburger SV                  34  13  2  2  27:13    6  2  9  22:34    49:47   +2   61
 6. Borussia Dortmund             34   8  9  0  34:11    7  5  5  26:26    60:37  +23   59
 7. 1899 Hoffenheim               34   9  5  3  30:18    6  5  6  33:31    63:49  +14   55
 8. FC Schalke 04                 34   9  3  5  26:15    5  5  7  21:20    47:35  +12   50
 9. Bayer Leverkusen              34   6  5  6  31:22    8  2  7  28:24    59:46  +13   49
10. Werder Bremen                 34  10  4  3  43:22    2  5 10  21:28    64:50  +14   45
11. Hannover 96                   34   8  7  2  31:25    2  3 12  18:44    49:69  -20   40
12. 1. FC Köln                    34   4  5  8  14:25    7  1  9  21:25    35:50  -15   39
13. Eintracht Frankfurt           34   5  4  8  26:29    3  5  9  13:31    39:60  -21   33
14. VfL Bochum                    34   5  4  8  23:28    2  7  8  16:27    39:55  -16   32
15. Bor. Mönchengladbach          34   5  4  8  23:27    3  3 11  16:35    39:62  -23   31
16. Energie Cottbus               34   6  1 10  19:27    2  5 10  11:30    30:57  -27   30
17. Karlsruher SC                 34   5  4  8  18:22    3  1 13  12:32    30:54  -24   29
18. Arminia Bielefeld             34   2  8  7  16:26    2  8  7  13:30    29:56  -27   28
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Freiburg                      34  12  3  2  34:14    9  2  6  26:22    60:36  +24   68
 2. Mainz                         34   7  6  4  32:22   11  3  3  30:15    62:37  +25   63
 3. Nürnberg                      34  13  3  1  31:7     3  9  5  20:22    51:29  +22   60
 4. Aachen                        34  12  2  3  34:16    4  6  7  24:22    58:38  +20   56
 5. Greuther Fürth                34   9  5  3  36:21    7  3  7  24:25    60:46  +14   56
 6. Duisburg                      34   8  5  4  33:18    6  8  3  23:18    56:36  +20   55
 7. St Pauli                      33  11  4  2  32:19    2  2 12  19:40    51:59   -8   45
 8. Oberhausen                    34   8  4  5  18:22    3  5  9  17:32    35:54  -19   42
 9. Koblenz                       34   8  4  5  31:22    3  4 10  16:35    47:57  -10   41
10. Ahlen                         34   6  3  8  19:26    5  5  7  19:31    38:57  -19   41
11. Augsburg                      34   7  6  4  26:18    3  4 10  17:28    43:46   -3   40
12. München 1860                  34   5  8  4  26:21    4  4  9  18:25    44:46   -2   39
13. Hansa Rostock                 34   7  6  4  34:17    1  8  8  18:36    52:53   -1   38
14. Frankfurt FSV                 34   8  5  4  20:18    1  6 10  14:29    34:47  -13   38
15. Osnabruck                     34   6  8  3  25:22    2  4 11  16:38    41:60  -19   36
16. Kaiserslautern                16  10  4  2  33:15    0  0  0   0:0     33:15  +18   34
17. Ingolstadt                    34   5  5  7  25:24    2  5 10  13:30    38:54  -16   31
18. Wehen                         34   4  6  7  18:21    1  6 10  10:28    28:49  -21   27
19. Kaiserslautern                18   1  0  0   2:0     4  3 10  18:33    20:33  -13   18
20. St. Pauli                      1   0  0  0   0:0     1  0  0   1:0      1:0    +1    3
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

