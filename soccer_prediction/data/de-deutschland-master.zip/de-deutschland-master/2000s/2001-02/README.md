

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund             34  12  3  2  31:12    9  4  4  31:21    62:33  +29   70
 2. Bayer Leverkusen              34  14  1  2  46:13    7  5  5  31:25    77:38  +39   69
 3. Bayern München                34  12  5  0  42:10    8  3  6  23:15    65:25  +40   68
 4. Hertha BSC                    34  13  2  2  40:13    5  5  7  21:25    61:38  +23   61
 5. FC Schalke 04                 34  13  2  2  38:14    5  5  7  14:22    52:36  +16   61
 6. Werder Bremen                 34  11  2  4  29:21    6  3  8  25:22    54:43  +11   56
 7. 1. FC Kaiserslautern          34  11  4  2  39:21    6  1 10  23:32    62:53   +9   56
 8. VfB Stuttgart                 34   8  5  4  25:16    5  6  6  22:27    47:43   +4   50
 9. TSV 1860 München              34   8  3  6  31:33    7  2  8  28:26    59:59        50
10. VfL Wolfsburg                 34   9  3  5  34:18    4  4  9  23:31    57:49   +8   46
11. Hamburger SV                  34   7  6  4  35:25    3  4 10  16:32    51:57   -6   40
12. Bor. Mönchengladbach          34   6  5  6  21:21    3  7  7  20:32    41:53  -12   39
13. Energie Cottbus               34   8  4  5  27:21    1  4 12   9:39    36:60  -24   35
14. Hansa Rostock                 34   6  6  5  20:18    3  1 13  15:36    35:54  -19   34
15. 1. FC Nürnberg                34   7  3  7  21:23    3  1 13  13:34    34:57  -23   34
16. SC Freiburg                   34   6  5  6  25:26    1  4 12  12:38    37:64  -27   30
17. 1. FC Köln                    34   5  5  7  16:21    2  3 12  10:40    26:61  -35   29
18. FC St. Pauli                  34   4  4  9  19:28    0  6 11  18:42    37:70  -33   22
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hannover                      34  14  2  1  51:12    8  7  2  42:25    93:37  +56   75
 2. Bielefeld                     34  12  3  2  43:17    7  5  5  25:21    68:38  +30   65
 3. Bochum                        34  12  5  0  45:19    7  3  7  24:30    69:49  +20   65
 4. Mainz                         34   9  7  1  38:20    9  3  5  28:18    66:38  +28   64
 5. Greuther Fürth                34  10  5  2  33:20    6  6  5  29:21    62:41  +21   59
 6. Union Berlin                  34  11  2  4  36:15    5  6  6  25:26    61:41  +20   56
 7. Ein Frankfurt                 34   6  8  3  28:24    8  4  5  24:20    52:44   +8   54
 8. Ahlen                         34   7  5  5  28:27    7  1  9  32:43    60:70  -10   48
 9. Mannheim                      34   8  4  5  28:19    4  5  8  14:29    42:48   -6   45
10. Reutlingen                    34  10  2  5  32:19    3  3 11  21:38    53:57   -4   44
11. Duisburg                      34   7  6  4  36:25    4  4  9  20:32    56:57   -1   43
12. Oberhausen                    34   6  3  8  27:23    5  6  6  28:26    55:49   +6   42
13. Karlsruhe                     34   8  2  7  28:22    3  6  8  17:29    45:51   -6   41
14. Aachen                        34   9  3  5  26:23    3  1 13  15:44    41:67  -26   40
15. Unterhaching                  34   6  6  5  25:17    4  2 11  15:32    40:49   -9   38
16. Saarbrücken                   34   5  4  8  18:28    1  3 13  12:46    30:74  -44   25
17. Schweinfurt                   34   6  5  6  23:27    0  1 16   7:43    30:70  -40   24
18. Babelsberg                    34   3  0 14  19:41    1  6 10  20:41    39:82  -43   18
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

