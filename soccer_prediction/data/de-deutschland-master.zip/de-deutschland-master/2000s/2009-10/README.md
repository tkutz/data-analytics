

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  12  4  1  39:13    8  6  3  33:18    72:31  +41   70
 2. FC Schalke 04                 34  11  2  4  29:15    8  6  3  24:16    53:31  +22   65
 3. Werder Bremen                 34   8  6  3  34:21    9  4  4  37:19    71:40  +31   61
 4. Bayer Leverkusen              34  11  5  1  37:14    4  9  4  28:24    65:38  +27   59
 5. Borussia Dortmund             34  10  4  3  29:14    6  5  6  25:28    54:42  +12   57
 6. VfB Stuttgart                 34   8  5  4  28:21    7  5  5  23:20    51:41  +10   55
 7. Hamburger SV                  34   8  6  3  25:12    5  7  5  31:29    56:41  +15   52
 8. VfL Wolfsburg                 34   7  2  8  39:39    7  6  4  25:19    64:58   +6   50
 9. 1. FSV Mainz 05               34   9  6  2  22:14    3  5  9  14:28    36:42   -6   47
10. Eintracht Frankfurt           34   7  5  5  25:26    5  5  7  22:28    47:54   -7   46
11. 1899 Hoffenheim               34   5  6  6  26:20    6  3  8  18:22    44:42   +2   42
12. Bor. Mönchengladbach          34   8  5  4  25:22    2  4 11  18:38    43:60  -17   39
13. 1. FC Köln                    34   3  6  8  18:29    6  5  6  15:13    33:42   -9   38
14. SC Freiburg                   34   5  4  8  14:26    4  4  9  21:33    35:59  -24   35
15. Hannover 96                   34   5  4  8  27:33    4  2 11  16:34    43:67  -24   33
16. 1. FC Nürnberg                34   5  4  8  18:23    3  3 11  14:35    32:58  -26   31
17. VfL Bochum                    34   2  6  9  18:35    4  4  9  15:29    33:64  -31   28
18. Hertha BSC                    34   1  6 10  10:26    4  3 10  24:30    34:56  -22   24
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Kaiserslautern                34  10  5  2  33:11    9  5  3  23:17    56:28  +28   67
 2. St Pauli                      34  10  4  3  36:18   10  0  7  36:19    72:37  +35   64
 3. Augsburg                      34  11  5  1  37:15    6  6  5  23:25    60:40  +20   62
 4. Fortuna Düsseldorf            34  13  4  0  30:6     4  4  9  18:25    48:31  +17   59
 5. Bielefeld                     34  10  2  5  27:16    6  3  8  21:25    48:41   +7   53
 6. Paderborn                     34   9  4  4  29:19    5  5  7  20:30    49:49        51
 7. Duisburg                      34   5  6  6  30:25    9  2  6  21:21    51:46   +5   50
 8. München 1860                  34  10  3  4  30:18    4  3 10  13:27    43:45   -2   48
 9. Cottbus                       34   9  2  6  35:22    4  6  7  20:27    55:49   +6   47
10. Karlsruhe                     34   7  4  6  19:21    6  3  8  24:24    43:45   -2   46
11. Greuther Fürth                34   7  2  8  29:27    5  6  6  22:23    51:50   +1   44
12. Union Berlin                  34   9  5  3  23:16    2  6  9  19:29    42:45   -3   44
13. Aachen                        34   7  5  5  24:24    4  5  8  13:17    37:41   -4   43
14. Oberhausen                    34   9  1  7  20:20    3  4 10  18:32    38:52  -14   41
15. Frankfurt FSV                 34   5  8  4  17:19    4  3 10  12:31    29:50  -21   38
16. Hansa Rostock                 34   7  3  7  20:17    3  3 11  13:28    33:45  -12   36
17. Koblenz                       34   5  6  6  18:24    2  4 11  17:36    35:60  -25   31
18. Ahlen                         34   2  3 12   7:27    3  4 10  12:28    19:55  -36   22
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

