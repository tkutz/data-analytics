

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  42:14    8  7  2  25:18    67:32  +35   75
 2. Werder Bremen                 34  12  3  2  50:18    9  4  4  29:19    79:37  +42   70
 3. Hamburger SV                  34  10  2  5  26:16   11  3  3  27:14    53:30  +23   68
 4. FC Schalke 04                 34  10  6  1  32:16    6  7  4  15:15    47:31  +16   61
 5. Bayer Leverkusen              34   7  6  4  30:23    7  4  6  34:26    64:49  +15   52
 6. Hertha BSC                    34   8  5  4  30:22    4  7  6  22:26    52:48   +4   48
 7. Borussia Dortmund             34   8  4  5  23:18    3  9  5  22:24    45:42   +3   46
 8. 1. FC Nürnberg                34   9  3  5  31:20    3  5  9  18:31    49:51   -2   44
 9. VfB Stuttgart                 34   5  7  5  18:19    4  9  4  19:20    37:39   -2   43
10. Bor. Mönchengladbach          34   8  7  2  27:18    2  5 10  15:32    42:50   -8   42
11. 1. FSV Mainz 05               34   6  7  4  31:23    3  4 10  15:24    46:47   -1   38
12. Hannover 96                   34   4  9  4  27:24    3  8  6  16:23    43:47   -4   38
13. Arminia Bielefeld             34   8  2  7  18:15    2  5 10  14:32    32:47  -15   37
14. Eintracht Frankfurt           34   5  5  7  24:22    4  4  9  18:29    42:51   -9   36
15. VfL Wolfsburg                 34   4 10  3  16:16    3  3 11  17:39    33:55  -22   34
16. 1. FC Kaiserslautern          34   5  5  7  26:33    3  4 10  21:38    47:71  -24   33
17. 1. FC Köln                    34   5  4  8  24:29    2  5 10  25:42    49:71  -22   30
18. MSV Duisburg                  34   3  9  5  17:23    2  3 12  17:40    34:63  -29   27
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bochum                        34  10  3  4  30:15    9  6  2  25:11    55:26  +29   66
 2. Aachen                        34  12  1  4  31:13    8  4  5  30:23    61:36  +25   65
 3. Cottbus                       34   9  3  5  25:13    7  7  3  24:20    49:33  +16   58
 4. Freiburg                      34  12  4  1  29:12    4  4  9  12:21    41:33   +8   56
 5. Greuther Fürth                34   8  5  4  28:17    7  4  6  23:25    51:42   +9   54
 6. Karlsruhe                     34  12  2  3  39:19    3  6  8  16:26    55:45  +10   53
 7. Erzgebirge Aue                34   8  5  4  18:12    5  4  8  20:24    38:36   +2   48
 8. Burghausen                    34   6  6  5  21:21    6  5  6  24:28    45:49   -4   47
 9. Paderborn                     34   8  3  6  30:17    5  4  8  16:23    46:40   +6   46
10. Hansa Rostock                 34   9  1  7  26:19    4  3 10  18:30    44:49   -5   43
11. Offenbach                     34   6  4  7  25:30    6  3  8  17:23    42:53  -11   43
12. Braunschweig                  34   9  3  5  25:12    4  1 12  12:36    37:48  -11   43
13. München 1860                  34   6  6  5  21:17    5  3  9  20:27    41:44   -3   42
14. Unterhaching                  34   9  4  4  24:12    3  2 12  18:36    42:48   -6   42
15. Dresden                       34   8  3  6  26:22    3  5  9  13:23    39:45   -6   41
16. Saarbrücken                   34   6  4  7  23:30    5  1 11  14:33    37:63  -26   38
17. Ahlen                         34   5  5  7  20:21    4  3 10  16:29    36:50  -14   35
18. Siegen                        34   5  5  7  24:27    3  2 12  11:27    35:54  -19   31
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

