

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. VfB Stuttgart                 34  12  3  2  30:13    9  4  4  31:24    61:37  +24   70
 2. FC Schalke 04                 34  13  2  2  30:11    8  3  6  23:21    53:32  +21   68
 3. Werder Bremen                 34  11  1  5  33:18    9  5  3  43:22    76:40  +36   66
 4. Bayern München                34  11  4  2  29:14    7  2  8  26:26    55:40  +15   60
 5. Bayer Leverkusen              34   8  3  6  28:23    7  3  7  26:26    54:49   +5   51
 6. 1. FC Nürnberg                34   8  7  2  26:16    3  8  6  17:16    43:32  +11   48
 7. Hamburger SV                  34   4  9  4  22:19    6  6  5  21:18    43:37   +6   45
 8. VfL Bochum                    34   7  1  9  23:30    6  5  6  26:20    49:50   -1   45
 9. Borussia Dortmund             34   6  6  5  19:17    6  2  9  22:26    41:43   -2   44
10. Hertha BSC                    34   8  3  6  29:25    4  5  8  21:30    50:55   -5   44
11. Hannover 96                   34   5  6  6  23:24    7  2  8  18:26    41:50   -9   44
12. Arminia Bielefeld             34   8  4  5  29:24    3  5  9  18:25    47:49   -2   42
13. Energie Cottbus               34   6  5  6  21:22    5  3  9  17:27    38:49  -11   41
14. Eintracht Frankfurt           34   5  5  7  21:30    4  8  5  25:28    46:58  -12   40
15. VfL Wolfsburg                 34   6  6  5  22:22    2  7  8  15:23    37:45   -8   37
16. 1. FSV Mainz 05               34   6  4  7  20:28    2  6  9  14:29    34:57  -23   34
17. Alemannia Aachen              34   5  4  8  28:37    4  3 10  18:33    46:70  -24   34
18. Bor. Mönchengladbach          34   5  6  6  15:16    1  2 14   8:28    23:44  -21   26
~~~

(Source: `1-bundesliga.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Karlsruhe                     34  12  2  3  38:22    9  5  3  31:19    69:41  +28   70
 2. Hansa Rostock                 34   9  5  3  24:13    7  9  1  25:17    49:30  +19   62
 3. Duisburg                      34   8  5  4  34:20    8  7  2  32:20    66:40  +26   60
 4. Freiburg                      34   9  4  4  30:22    8  5  4  25:17    55:39  +16   60
 5. Greuther Fürth                34   9  3  5  30:21    7  3  7  23:19    53:40  +13   54
 6. Kaiserslautern                34   9  6  2  34:15    4  8  5  14:19    48:34  +14   53
 7. Augsburg                      34   9  4  4  24:13    5  6  6  19:19    43:32  +11   52
 8. München 1860                  34  11  2  4  31:15    3  4 10  16:34    47:49   -2   48
 9. FC Köln                       34   6  6  5  29:24    6  4  7  20:26    49:50   -1   46
10. Erzgebirge Aue                34  10  4  3  31:14    3  2 12  15:34    46:48   -2   45
11. Paderborn                     34   7  4  6  18:16    4  5  8  14:25    32:41   -9   42
12. Koblenz                       34   6  7  4  17:15    5  1 11  19:30    36:45   -9   41
13. CZ Jena                       34   6  5  6  24:25    3  6  8  16:31    40:56  -16   38
14. Offenbach                     34   6  5  6  23:22    3  4 10  19:37    42:59  -17   36
15. Essen                         34   4  8  5  22:18    4  3 10  12:22    34:40   -6   35
16. Unterhaching                  34   7  4  6  19:17    2  4 11  14:32    33:49  -16   35
17. Burghausen                    34   3  8  6  24:26    4  3 10  18:37    42:63  -21   32
18. Braunschweig                  34   4  4  9  14:20    0  7 10   6:28    20:48  -28   23
~~~

(Source: `2-bundesliga2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

